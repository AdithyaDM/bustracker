package com.example.bustrack

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
